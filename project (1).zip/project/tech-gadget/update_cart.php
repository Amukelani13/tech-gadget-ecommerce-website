<?php
require_once 'config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cart_id = $_POST['cart_id'] ?? 0;
    $action = $_POST['action'] ?? '';
    $user_id = $_SESSION['user_id'];
    
    $stmt = $pdo->prepare("SELECT quantity FROM cart WHERE id = ? AND user_id = ?");
    $stmt->execute([$cart_id, $user_id]);
    $cart_item = $stmt->fetch();
    
    if ($cart_item) {
        if ($action === 'increase') {
            $stmt = $pdo->prepare("UPDATE cart SET quantity = quantity + 1 WHERE id = ?");
            $stmt->execute([$cart_id]);
        } elseif ($action === 'decrease') {
            if ($cart_item['quantity'] > 1) {
                $stmt = $pdo->prepare("UPDATE cart SET quantity = quantity - 1 WHERE id = ?");
                $stmt->execute([$cart_id]);
            } else {
                $stmt = $pdo->prepare("DELETE FROM cart WHERE id = ?");
                $stmt->execute([$cart_id]);
            }
        }
    }
    
    echo json_encode(['success' => true]);
}
?>