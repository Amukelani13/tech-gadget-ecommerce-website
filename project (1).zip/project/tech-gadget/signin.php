<?php
$page_title = 'Sign In';
require_once 'config/database.php';
require_once 'includes/header.php';
?>

<div class="auth-container">
    <h2>Sign In</h2>
    
    <div id="signinAlert"></div>
    
    <form id="signinForm" onsubmit="submitSignin(event)">
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="signinEmail" name="email" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="signinPassword" name="password" required>
        </div>
        <button type="submit" class="btn-submit">Sign In</button>
    </form>
    
    <div class="auth-switch">
        Don't have an account? <a href="/tech-gadget/signup.php">Sign Up</a>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>