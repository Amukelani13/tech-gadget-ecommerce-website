<?php
$page_title = 'About';
require_once 'config/database.php';
require_once 'includes/header.php';
?>

<div class="container fade-in">
    <h1>About Tech Gadget</h1>
    
    <div class="about-content">
        <p>
            Tech Gadget is your premier destination for cutting-edge technology and innovative gadgets. Founded in 2020, we have been committed to bringing the latest and greatest tech products to enthusiasts and professionals across South Africa.
        </p>
        
        <p>
            Our mission is to make advanced technology accessible to everyone. We carefully curate our product selection to ensure that every item meets our high standards for quality, innovation, and value.
        </p>
        
        <h2>Why Choose Us?</h2>
        
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">✓</div>
                <h3>Quality Products</h3>
                <p>Carefully vetted product selection</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">💰</div>
                <h3>Best Prices</h3>
                <p>Competitive pricing in ZAR</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🚚</div>
                <h3>Fast Delivery</h3>
                <p>Nationwide shipping</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">💬</div>
                <h3>Expert Support</h3>
                <p>Dedicated customer service</p>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>