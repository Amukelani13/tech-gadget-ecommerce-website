<?php
$page_title = 'Home';
require_once 'config/database.php';
require_once 'includes/header.php';

$stmt = $pdo->query("SELECT * FROM products LIMIT 3");
$featured_products = $stmt->fetchAll();
?>

<div class="hero">
    <div class="hero-content fade-in">
        <h1>Welcome to Tech Gadget</h1>
        <p>Discover the Future of Technology</p>
        <a href="/tech-gadget/products.php" class="btn-primary">Shop Now</a>
    </div>
</div>

<div class="container">
    <h2 style="text-align: center; font-size: 2rem; margin-bottom: 2rem;">Featured Products</h2>
    <div class="products-grid" id="featuredProducts">
        <?php foreach ($featured_products as $product): ?>
            <div class="product-card slide-up">
                <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                <div class="product-info">
                    <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                    <p><?php echo htmlspecialchars($product['description']); ?></p>
                    <?php if ($product['video_url']): ?>
                        <div class="video-container">
                            <iframe src="<?php echo htmlspecialchars($product['video_url']); ?>" allowfullscreen loading="lazy"></iframe>
                        </div>
                    <?php endif; ?>
                    <div class="product-footer">
                        <span class="price">R<?php echo number_format($product['price'], 2); ?></span>
                        <button onclick="addToCart(<?php echo $product['id']; ?>, '<?php echo htmlspecialchars($product['name']); ?>')" class="btn-cart">
                            Add to Cart
                        </button>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>