<?php
$page_title = 'Sign Up';
require_once 'config/database.php';
require_once 'includes/header.php';
?>

<div class="auth-container">
    <h2>Sign Up</h2>
    
    <div id="signupAlert"></div>
    
    <form id="signupForm" onsubmit="submitSignup(event)">
        <div class="form-group">
            <label for="name">Full Name</label>
            <input type="text" id="signupName" name="name" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="signupEmail" name="email" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="signupPassword" name="password" required minlength="6">
            <small>Minimum 6 characters</small>
        </div>
        <button type="submit" class="btn-submit">Sign Up</button>
    </form>
    
    <div class="auth-switch">
        Already have an account? <a href="/tech-gadget/signin.php">Sign In</a>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>