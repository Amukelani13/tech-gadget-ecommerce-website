<?php
session_start();
session_destroy();
header('Location: /tech-gadget/index.php');
exit;
?>