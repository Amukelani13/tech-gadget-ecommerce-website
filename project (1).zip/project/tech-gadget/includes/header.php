<?php
require_once __DIR__ . '/../config/database.php';

$cart_count = 0;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT SUM(quantity) as total FROM cart WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $result = $stmt->fetch();
    $cart_count = $result['total'] ?? 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tech Gadget - <?php echo $page_title ?? 'Home'; ?></title>
    <link rel="stylesheet" href="/tech-gadget/css/style.css">
</head>
<body>
    <nav>
        <div class="nav-container">
            <a href="/tech-gadget/index.php" class="logo">
                <img src="/tech-gadget/images/Screenshot 2025-10-28 023909.png" alt="Tech Gadget Logo" class="logo-image" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                <div class="logo-icon" style="display:none;">TG</div>
                <span class="logo-text">Tech Gadget</span>
            </a>
            
            <button class="mobile-menu-toggle" id="mobileMenuToggle">
                <span></span>
                <span></span>
                <span></span>
            </button>
            
            <ul class="nav-menu" id="navMenu">
                <li><a href="/tech-gadget/index.php">Home</a></li>
                <li><a href="/tech-gadget/about.php">About</a></li>
                <li><a href="/tech-gadget/products.php">Products</a></li>
                <li><a href="/tech-gadget/contact.php">Contact</a></li>
                <li>
                    <a href="/tech-gadget/cart.php" class="cart-link">
                        <span>🛒</span> Cart
                        <?php if ($cart_count > 0): ?>
                            <span class="cart-badge" id="cartBadge"><?php echo $cart_count; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <a href="/tech-gadget/logout.php" class="btn">Sign Out</a>
                    <?php else: ?>
                        <a href="/tech-gadget/signin.php" class="btn">Sign In</a>
                    <?php endif; ?>
                </li>
            </ul>
        </div>
    </nav>
    
    <div id="alertContainer" class="alert-container"></div>