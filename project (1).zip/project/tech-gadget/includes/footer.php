<footer>
        <div class="footer-content">
            <div class="footer-section">
                <h3>Tech Gadget</h3>
                <p>Your premier destination for cutting-edge technology and innovative gadgets.</p>
            </div>
            <div class="footer-section">
                <h3>Contact Information</h3>
                <div class="contact-info">
                    <div>📍 123 Tech Street, Johannesburg, Gauteng 2000</div>
                    <div>📞 +27 11 123 4567</div>
                    <div>✉️ info@techgadget.co.za</div>
                </div>
            </div>
            <div class="footer-section">
                <h3>Follow Us</h3>
                <div class="social-links">
                    <a href="#" onclick="showAlert('Opening Facebook...', 'info'); return false;">Facebook</a>
                    <a href="#" onclick="showAlert('Opening Twitter...', 'info'); return false;">Twitter</a>
                    <a href="#" onclick="showAlert('Opening Instagram...', 'info'); return false;">Instagram</a>
                    <a href="#" onclick="showAlert('Opening LinkedIn...', 'info'); return false;">LinkedIn</a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> Tech Gadget. All rights reserved.</p>
        </div>
    </footer>
    
    <script src="/tech-gadget/js/main.js"></script>
</body>
</html>