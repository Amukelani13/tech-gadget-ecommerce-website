<?php
require_once 'config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /tech-gadget/signin.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    
    $stmt = $pdo->prepare("
        SELECT c.*, p.price 
        FROM cart c 
        JOIN products p ON c.product_id = p.id 
        WHERE c.user_id = ?
    ");
    $stmt->execute([$user_id]);
    $cart_items = $stmt->fetchAll();
    
    if (!empty($cart_items)) {
        $total = 0;
        foreach ($cart_items as $item) {
            $total += $item['price'] * $item['quantity'];
        }
        
        $total_with_vat = $total * 1.15;
        
        $pdo->beginTransaction();
        
        try {
            $stmt = $pdo->prepare("INSERT INTO transactions (user_id, total_amount, status) VALUES (?, ?, 'completed')");
            $stmt->execute([$user_id, $total_with_vat]);
            $transaction_id = $pdo->lastInsertId();
            
            foreach ($cart_items as $item) {
                $stmt = $pdo->prepare("INSERT INTO transaction_items (transaction_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                $stmt->execute([$transaction_id, $item['product_id'], $item['quantity'], $item['price']]);
            }
            
            $stmt = $pdo->prepare("DELETE FROM cart WHERE user_id = ?");
            $stmt->execute([$user_id]);
            
            $pdo->commit();
            
            $_SESSION['checkout_success'] = "Order placed successfully! Transaction ID: $transaction_id - Total: R" . number_format($total_with_vat, 2);
        } catch (Exception $e) {
            $pdo->rollBack();
            $_SESSION['checkout_error'] = "Checkout failed. Please try again.";
        }
    }
}

header('Location: /tech-gadget/cart.php');
exit;
?>