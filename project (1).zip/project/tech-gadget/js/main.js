document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const navMenu = document.getElementById('navMenu');
    
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            this.classList.toggle('active');
        });
    }
    
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, observerOptions);
    
    document.querySelectorAll('.slide-up, .fade-in').forEach(el => {
        observer.observe(el);
    });
});

function showAlert(message, type = 'success') {
    const alertContainer = document.getElementById('alertContainer');
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-slide-in`;
    alert.textContent = message;
    
    alertContainer.appendChild(alert);
    
    setTimeout(() => {
        alert.classList.add('alert-slide-out');
        setTimeout(() => alert.remove(), 300);
    }, 3000);
}

function addToCart(productId, productName) {
    const formData = new FormData();
    formData.append('product_id', productId);
    
    fetch('/tech-gadget/add_to_cart.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert(`${productName} added to cart!`, 'success');
            updateCartBadge(data.cart_count);
        } else {
            if (data.message === 'Please sign in first') {
                showAlert('Please sign in to add items to cart', 'error');
                setTimeout(() => {
                    window.location.href = '/tech-gadget/signin.php';
                }, 1500);
            } else {
                showAlert('Failed to add to cart', 'error');
            }
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('An error occurred', 'error');
    });
}

function updateCartBadge(count) {
    const badge = document.getElementById('cartBadge');
    if (badge) {
        badge.textContent = count;
        if (count > 0) {
            badge.style.display = 'inline-block';
        } else {
            badge.style.display = 'none';
        }
    }
}

function removeFromCart(cartId) {
    if (!confirm('Remove this item from cart?')) return;
    
    const formData = new FormData();
    formData.append('cart_id', cartId);
    
    fetch('/tech-gadget/remove_from_cart.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const cartItem = document.getElementById(`cartItem${cartId}`);
            cartItem.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                cartItem.remove();
                checkEmptyCart();
            }, 300);
            showAlert('Item removed from cart', 'success');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('Failed to remove item', 'error');
    });
}

function updateQuantity(cartId, action) {
    const formData = new FormData();
    formData.append('cart_id', cartId);
    formData.append('action', action);
    
    fetch('/tech-gadget/update_cart.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('Failed to update quantity', 'error');
    });
}

function clearCart() {
    if (!confirm('Are you sure you want to clear your entire cart?')) return;
    
    fetch('/tech-gadget/clear_cart.php', {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showAlert('Cart cleared successfully', 'success');
            setTimeout(() => location.reload(), 1000);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('Failed to clear cart', 'error');
    });
}

function checkEmptyCart() {
    const cartItems = document.querySelectorAll('.cart-item');
    if (cartItems.length === 0) {
        location.reload();
    }
}

function confirmCheckout() {
    if (confirm('Proceed to checkout?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '/tech-gadget/checkout.php';
        document.body.appendChild(form);
        form.submit();
    }
}

function searchProducts() {
    const searchInput = document.getElementById('searchInput');
    const filter = searchInput.value.toLowerCase();
    const productCards = document.querySelectorAll('.product-card');
    
    let visibleCount = 0;
    productCards.forEach(card => {
        const name = card.getAttribute('data-name');
        if (name.includes(filter)) {
            card.style.display = 'block';
            visibleCount++;
        } else {
            card.style.display = 'none';
        }
    });
    
    if (visibleCount === 0 && filter !== '') {
        showAlert('No products found', 'info');
    }
}

function sortProducts() {
    const sortSelect = document.getElementById('sortSelect');
    const sortValue = sortSelect.value;
    const grid = document.getElementById('productsGrid');
    const cards = Array.from(grid.querySelectorAll('.product-card'));
    
    cards.sort((a, b) => {
        if (sortValue === 'name-asc') {
            return a.getAttribute('data-name').localeCompare(b.getAttribute('data-name'));
        } else if (sortValue === 'name-desc') {
            return b.getAttribute('data-name').localeCompare(a.getAttribute('data-name'));
        } else if (sortValue === 'price-asc') {
            return parseFloat(a.getAttribute('data-price')) - parseFloat(b.getAttribute('data-price'));
        } else if (sortValue === 'price-desc') {
            return parseFloat(b.getAttribute('data-price')) - parseFloat(a.getAttribute('data-price'));
        }
        return 0;
    });
    
    cards.forEach(card => grid.appendChild(card));
    showAlert('Products sorted', 'success');
}

function submitContactForm(event) {
    event.preventDefault();
    
    const name = document.getElementById('contactName').value;
    const email = document.getElementById('contactEmail').value;
    const message = document.getElementById('contactMessage').value;
    
    if (name && email && message) {
        showAlert('Thank you for your message! We will get back to you soon.', 'success');
        document.getElementById('contactForm').reset();
    } else {
        showAlert('Please fill in all fields', 'error');
    }
}

function submitSignin(event) {
    event.preventDefault();
    
    const email = document.getElementById('signinEmail').value;
    const password = document.getElementById('signinPassword').value;
    
    const formData = new FormData();
    formData.append('email', email);
    formData.append('password', password);
    
    fetch('/tech-gadget/process_signin.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        const alertDiv = document.getElementById('signinAlert');
        if (data.success) {
            alertDiv.innerHTML = `<div class="alert alert-success">${data.message}</div>`;
            setTimeout(() => {
                window.location.href = '/tech-gadget/index.php';
            }, 1000);
        } else {
            alertDiv.innerHTML = `<div class="alert alert-error">${data.message}</div>`;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        const alertDiv = document.getElementById('signinAlert');
        alertDiv.innerHTML = '<div class="alert alert-error">An error occurred</div>';
    });
}

function submitSignup(event) {
    event.preventDefault();
    
    const name = document.getElementById('signupName').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    
    if (password.length < 6) {
        const alertDiv = document.getElementById('signupAlert');
        alertDiv.innerHTML = '<div class="alert alert-error">Password must be at least 6 characters</div>';
        return;
    }
    
    const formData = new FormData();
    formData.append('name', name);
    formData.append('email', email);
    formData.append('password', password);
    
    fetch('/tech-gadget/process_signup.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        const alertDiv = document.getElementById('signupAlert');
        if (data.success) {
            alertDiv.innerHTML = `<div class="alert alert-success">${data.message}</div>`;
            setTimeout(() => {
                window.location.href = '/tech-gadget/signin.php';
            }, 1500);
        } else {
            alertDiv.innerHTML = `<div class="alert alert-error">${data.message}</div>`;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        const alertDiv = document.getElementById('signupAlert');
        alertDiv.innerHTML = '<div class="alert alert-error">An error occurred</div>';
    });
}

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

document.querySelectorAll('input[required]').forEach(input => {
    input.addEventListener('invalid', function(e) {
        e.preventDefault();
        this.classList.add('error');
        showAlert('Please fill in all required fields', 'error');
    });
    
    input.addEventListener('input', function() {
        this.classList.remove('error');
    });
});