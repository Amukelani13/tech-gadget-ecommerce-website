<?php
$page_title = 'Shopping Cart';
require_once 'config/database.php';
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /tech-gadget/signin.php');
    exit;
}

$success = $_SESSION['checkout_success'] ?? '';
$error = $_SESSION['checkout_error'] ?? '';
unset($_SESSION['checkout_success'], $_SESSION['checkout_error']);

$stmt = $pdo->prepare("
    SELECT c.*, p.name, p.price, p.image_url 
    FROM cart c 
    JOIN products p ON c.product_id = p.id 
    WHERE c.user_id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$cart_items = $stmt->fetchAll();

$total = 0;
foreach ($cart_items as $item) {
    $total += $item['price'] * $item['quantity'];
}
?>

<div class="container">
    <h1>Shopping Cart</h1>
    
    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <?php if (empty($cart_items)): ?>
        <div class="empty-cart">
            <div class="empty-cart-icon">🛒</div>
            <p>Your cart is empty</p>
            <a href="/tech-gadget/products.php" class="btn-primary">Continue Shopping</a>
        </div>
    <?php else: ?>
        <div id="cartItems">
            <?php foreach ($cart_items as $item): ?>
                <div class="cart-item" id="cartItem<?php echo $item['id']; ?>">
                    <img src="<?php echo htmlspecialchars($item['image_url']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                    <div class="cart-item-info">
                        <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                        <p class="item-price">R<?php echo number_format($item['price'], 2); ?></p>
                    </div>
                    <div class="quantity-controls">
                        <button onclick="updateQuantity(<?php echo $item['id']; ?>, 'decrease')">-</button>
                        <span class="quantity-display"><?php echo $item['quantity']; ?></span>
                        <button onclick="updateQuantity(<?php echo $item['id']; ?>, 'increase')">+</button>
                    </div>
                    <div class="item-total">R<?php echo number_format($item['price'] * $item['quantity'], 2); ?></div>
                    <button onclick="removeFromCart(<?php echo $item['id']; ?>)" class="remove-btn">✕</button>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="cart-total">
            <div class="total-row">
                <span>Subtotal:</span>
                <span id="subtotal">R<?php echo number_format($total, 2); ?></span>
            </div>
            <div class="total-row">
                <span>VAT (15%):</span>
                <span id="vat">R<?php echo number_format($total * 0.15, 2); ?></span>
            </div>
            <div class="total-row total-final">
                <span>Total:</span>
                <span class="total-amount" id="totalAmount">R<?php echo number_format($total * 1.15, 2); ?></span>
            </div>
            <div class="cart-actions">
                <button onclick="clearCart()" class="btn-secondary">Clear Cart</button>
                <button onclick="confirmCheckout()" class="btn-checkout">Checkout</button>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>