<?php
$page_title = 'Products';
require_once 'config/database.php';
require_once 'includes/header.php';

$stmt = $pdo->query("SELECT * FROM products");
$products = $stmt->fetchAll();
?>

<div class="container">
    <div class="products-header">
        <h1>Our Products</h1>
        <div class="search-filter">
            <input type="text" id="searchInput" placeholder="Search products..." onkeyup="searchProducts()">
            <select id="sortSelect" onchange="sortProducts()">
                <option value="">Sort by...</option>
                <option value="name-asc">Name (A-Z)</option>
                <option value="name-desc">Name (Z-A)</option>
                <option value="price-asc">Price (Low to High)</option>
                <option value="price-desc">Price (High to Low)</option>
            </select>
        </div>
    </div>
    
    <div class="products-grid" id="productsGrid">
        <?php foreach ($products as $product): ?>
            <div class="product-card" data-name="<?php echo strtolower($product['name']); ?>" data-price="<?php echo $product['price']; ?>">
                <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                <div class="product-info">
                    <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                    <p><?php echo htmlspecialchars($product['description']); ?></p>
                    <div class="product-footer">
                        <span class="price">R<?php echo number_format($product['price'], 2); ?></span>
                        <button onclick="addToCart(<?php echo $product['id']; ?>, '<?php echo htmlspecialchars($product['name']); ?>')" class="btn-cart">
                            Add to Cart
                        </button>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>