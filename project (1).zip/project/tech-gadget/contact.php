<?php
$page_title = 'Contact';
require_once 'config/database.php';
require_once 'includes/header.php';
?>

<div class="container">
    <h1>Contact Us</h1>
    
    <div class="contact-grid">
        <div class="contact-info-section">
            <h2>Get in Touch</h2>
            <div class="contact-details">
                <div class="contact-item">
                    <span class="contact-icon">📍</span>
                    <div>
                        <h3>Address</h3>
                        <p>123 Tech Street, Johannesburg, Gauteng 2000</p>
                    </div>
                </div>
                <div class="contact-item">
                    <span class="contact-icon">📞</span>
                    <div>
                        <h3>Phone</h3>
                        <p>+27 11 123 4567</p>
                    </div>
                </div>
                <div class="contact-item">
                    <span class="contact-icon">✉️</span>
                    <div>
                        <h3>Email</h3>
                        <p>info@techgadget.co.za</p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="contact-form-section">
            <h2>Send us a Message</h2>
            <form id="contactForm" onsubmit="submitContactForm(event)">
                <div class="form-group">
                    <input type="text" id="contactName" name="name" placeholder="Your Name" required>
                </div>
                <div class="form-group">
                    <input type="email" id="contactEmail" name="email" placeholder="Your Email" required>
                </div>
                <div class="form-group">
                    <textarea id="contactMessage" name="message" placeholder="Your Message" rows="4" required></textarea>
                </div>
                <button type="submit" class="btn-submit">Send Message</button>
            </form>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>